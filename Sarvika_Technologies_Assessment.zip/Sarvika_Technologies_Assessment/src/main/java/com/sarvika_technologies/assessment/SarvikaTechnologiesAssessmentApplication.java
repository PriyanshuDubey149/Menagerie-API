package com.sarvika_technologies.assessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SarvikaTechnologiesAssessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SarvikaTechnologiesAssessmentApplication.class, args);
	}

}
