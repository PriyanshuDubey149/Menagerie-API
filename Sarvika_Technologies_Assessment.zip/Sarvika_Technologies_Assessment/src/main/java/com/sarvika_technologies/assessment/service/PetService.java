package com.sarvika_technologies.assessment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sarvika_technologies.assessment.model.Pet;
import com.sarvika_technologies.assessment.repository.PetRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PetService {

	@Autowired
	private PetRepository petRepository;

	public List<Pet> getAllPets(String species) {
		if (species != null && !species.isEmpty()) {
			return petRepository.findBySpecies(species);
		}
		return petRepository.findAll();
	}

	public Optional<Pet> getPetById(Integer id) {
		return petRepository.findById(id);
	}

	public Pet addPet(Pet pet) {
		return petRepository.save(pet);
	}

	public Pet updatePet(Pet pet) {
		return petRepository.save(pet);
	}

	public void deletePet(Integer id) {
		petRepository.deleteById(id);
	}
}
