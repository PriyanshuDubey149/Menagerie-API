package com.sarvika_technologies.assessment.model;

import jakarta.persistence.*;

import jakarta.persistence.Entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Event {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private Date date;
	private String type;
	private String remark;

	@ManyToOne
	@JoinColumn(name = "pet_id")
	@JsonBackReference
	private Pet pet;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Pet getPet() {
		return pet;
	}

	public void setPet(Pet pet) {
		this.pet = pet;
	}

}
