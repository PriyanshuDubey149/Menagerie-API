package com.sarvika_technologies.assessment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.sarvika_technologies.assessment.model.Event;
import com.sarvika_technologies.assessment.service.EventService;
import com.sarvika_technologies.assessment.service.PetService;

import java.util.List;

@RestController
@RequestMapping("/pets/{id}/events")
public class EventController {

	@Autowired
	private EventService eventService;

	@Autowired
	private PetService petService;

	@GetMapping
	public ResponseEntity<List<Event>> getEventsByPetId(@PathVariable Integer id) {
		if (petService.getPetById(id).isPresent()) {
			return ResponseEntity.ok(eventService.getEventsByPetId(id));
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping
	public ResponseEntity<Event> addEvent(@PathVariable Integer id, @RequestBody Event event) {
		return petService.getPetById(id).map(pet -> {
			event.setPet(pet);
			return new ResponseEntity<>(eventService.addEvent(event), HttpStatus.CREATED);
		}).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}
}
